<?php include 'incl/header.php'; ?>

<div class="page__wrap">
    <div class="main-slider">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="false">
            <div class="carousel-inner">
                <div class="carousel-item active main-slider-caption">
                    <img src="assets/img/hero-image.jpg" class="d-block w-100" alt="...">
                    <div class="caption-content">
                        <div class="container">
                            <div class="caption-content-inner">
                                <h1>we are the lawn experts</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores dolore obcaecati odit ut! Architecto eos
                                    facilis
                                    laudantium maxime vel vero.</p>

                                <div class="button-group">
                                    <input type="button" class="btn-white-fill" value="learn more">
                                    <input type="button" class="btn-green-fill" value="purchase theme">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item main-slider-caption">
                    <img src="assets/img/hero-image-2.jpg" class="d-block w-100" alt="...">
                    <div class="caption-content">
                        <div class="container">
                            <div class="caption-content-inner">
                                <h1>we are the lawn experts</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores dolore obcaecati odit ut! Architecto eos
                                    facilis
                                    laudantium maxime vel vero.</p>

                                <div class="button-group">
                                    <input type="button" class="btn-white-fill" value="learn more">
                                    <input type="button" class="btn-green-fill" value="purchase theme">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item main-slider-caption">
                    <img src="assets/img/hero-image-3.jpg" class="d-block w-100" alt="...">
                    <div class="caption-content">
                        <div class="container">
                            <div class="caption-content-inner">
                                <h1>we are the lawn experts</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores dolore obcaecati odit ut! Architecto eos
                                    facilis
                                    laudantium maxime vel vero.</p>

                                <div class="button-group">
                                    <input type="button" class="btn-white-fill" value="learn more">
                                    <input type="button" class="btn-green-fill" value="purchase theme">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.main-slider-inner-->
            <div class="slider-buttons">
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="icon-angle-left" aria-hidden="true"></span>

                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="icon-angle-right" aria-hidden="true"></span>

                </a>
            </div>

        </div>


    </div><!--/.main-slider-->
    <div class="quality-section section-space-top">
        <div class="container">
            <div class="quality-section-inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="quality-img">
                            <img src="assets/img/quality-image-1.png" alt="" class="d-block mx-auto">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="quality-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="section-title">
                                        <i class="icon-lawn-mower"></i>
                                        <h2>Welcome <span class="brand-color">lawn express</span></h2>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam est explicabo nobis odio, quis
                                            quod. Lorem ipsum dolor. </p>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="quality-statement">
                                        <i class="icon-watering1"></i>
                                        <p class="strong">certified workers</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet consequuntur laudantium nobis quod
                                            repellat sit.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quality-statement">
                                        <i class="icon-nature-protect"></i>
                                        <p class="strong">24h free helpline</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa ducimus esse facilis fuga, qui
                                            recusandae.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quality-statement">
                                        <i class="icon-ecologism"></i>
                                        <p class="strong">honest & reliable</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda quam recusandae sapiente ullam
                                            voluptatum? Odit.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quality-statement">
                                        <i class="icon-dig"></i>
                                        <p class="strong">10+ years experience</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto asperiores aspernatur dolorem
                                            impedit odio repudiandae!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.quality-section-inner-->
        </div><!--/.container-->
    </div><!--/.quality-section-->


    <div class="quality-stats-section" style="background-image: url('assets/img/quality-stats-bg.jpg');">
        <div class="stats-section-overlay">
            <div class="container">
                <div class="stats-section-inner section-space">

                    <div class="excellence-content">
                        <div class="item">
                            <h1>4500+ <small>tree plantation</small></h1>
                            <i class="icon-nature-protect"></i>

                        </div>
                        <div class="item">
                            <h1>100+ <small>qualified staff</small></h1>
                            <i class="icon-tractor"></i>

                        </div>
                        <div class="item">
                            <h1>350+ <small>garden tools</small></h1>
                            <i class="icon-transport-cart1"></i>

                        </div>
                        <div class="item">
                            <h1>1200+ <small>satisfied clients</small></h1>
                            <i class="icon-recycling1"></i>

                        </div>
                    </div>

                </div><!--/.stats-section-inner-->
            </div><!--/.container-->
        </div>
    </div><!--/.quality-stats-section-->

    <div class="services-section section-space" style="background-image: url('assets/img/services-section-bg.jpg')">
        <div class="container">
            <div class="services-section-inner">
                <div class="section-title text-center">
                    <i class="icon-lawn-mower"></i>
                    <h2>our <span>services</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias dolorum hic ipsam iusto, quis repellendus.</p>
                </div>
                <div class="services-content">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="service-col text-center">
                                <i class="icon-nature-protect"></i>
                                <p><strong>landscape caring</strong></p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                    officia.</p>
                                <a href="#">read more</a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="service-col text-center">
                                <i class="icon-nature-protect"></i>
                                <p><strong>landscape caring</strong></p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                    officia.</p>
                                <a href="#">read more</a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="service-col text-center">
                                <i class="icon-nature-protect"></i>
                                <p><strong>landscape caring</strong></p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                    officia.</p>
                                <a href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="service-second-row">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="service-col text-center">
                                    <i class="icon-nature-protect"></i>
                                    <p><strong>landscape caring</strong></p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                        officia.</p>
                                    <a href="#">read more</a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="service-col text-center">
                                    <i class="icon-nature-protect"></i>
                                    <p><strong>landscape caring</strong></p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                        officia.</p>
                                    <a href="#">read more</a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="service-col text-center">
                                    <i class="icon-nature-protect"></i>
                                    <p><strong>landscape caring</strong></p>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae debitis dolor inventore laborum libero
                                        officia.</p>
                                    <a href="#">read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="button-group text-center">
                            <button class="btn-green-fill">load more</button>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.container-->
    </div><!--/.services-section-->
        <div class="hm-gallery-section section-space">
            <div class="section-title text-center">
                <i class="icon-lawn-mower"></i>
                <h2>projects <span>gallery</span></h2>
            </div>
            <ul class="nav nav-pills mb-3 gallery-tabs" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home"
                       aria-selected="true">Show All Projects</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-lawn-care" role="tab" aria-controls="pills-profile"
                       aria-selected="false">Lawn Care</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-gardening" role="tab" aria-controls="pills-contact"
                       aria-selected="false">Gardening</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-rubbish-cleanup" role="tab" aria-controls="pills-contact"
                       aria-selected="false">Rubbish Cleanup</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-planting" role="tab" aria-controls="pills-contact"
                       aria-selected="false">Planting</a>
                </li>
            </ul>
            <div class="tab-content hm-gallery-images" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                    <div class="gallery">
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-1.jpg"><img src="assets/img/gardener-image-1.jpg" alt="" title=""/></a>

                    </div>
                </div>
                <div class="tab-pane fade" id="pills-lawn-care" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div class="gallery">
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-2.jpg"><img src="assets/img/gardener-image-2.jpg" alt="" title=""/></a>
                    </div>

                </div>
                <div class="tab-pane fade" id="pills-gardening" role="tabpanel" aria-labelledby="pills-contact-tab">
                   <div class="gallery">
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-3.jpg"><img src="assets/img/gardener-image-3.jpg" alt="" title=""/></a>
                   </div>
                </div>
                <div class="tab-pane fade" id="pills-rubbish-cleanup" role="tabpanel" aria-labelledby="pills-contact-tab">
                   <div class="gallery">
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                       <a href="assets/img/gardener-image-5.jpg"><img src="assets/img/gardener-image-5.jpg" alt="" title=""/></a>
                   </div>
                </div>
                <div class="tab-pane fade" id="pills-planting" role="tabpanel" aria-labelledby="pills-contact-tab">
                    <div class="gallery">
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                        <a href="assets/img/gardener-image-4.jpg"><img src="assets/img/gardener-image-4.jpg" alt="" title=""/></a>
                    </div>
                </div>
               <div class="button-group text-center">
                   <a href="#" class="btn-no-fill">View More</a>
               </div>
            </div>
        </div> <!--/.hm-gallery-section-->



    <div class="section-team section-space" style="background-image: url('assets/img/services-section-bg.jpg');">
        <div class="container">
            <div class="section-team-inner">
                <div class="section-title text-center">
                    <i class="icon-lawn-mower"></i>
                    <h2>the <span>experts team</span></h2>
                </div>
                <div class="owl-carousel owl-theme team-carousel">
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-1.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>Thomas Nick <small>Gardener</small></h4>
                        </div>
                    </div>
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-2.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>James Harry <small>Gardener</small></h4>
                        </div>
                    </div>
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-3.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>Mark Brad <small>Gardener</small></h4>
                        </div>
                    </div>
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-4.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>Daniel Jacob <small>Gardener</small></h4>
                        </div>
                    </div>
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-5.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>Lucy Rose <small>Gardener</small></h4>
                        </div>
                    </div>
                    <div class="item">
                        <div class="team-image">
                            <img src="assets/img/gardener-image-6.jpg" alt="">
                            <div class="team-overlay">
                                <div class="team-social-links">
                                    <a href="#"><i class="icon-twitter"></i></a>
                                    <a href="#"><i class="icon-facebook-f"></i></a>
                                    <a href="#"><i class="icon-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="team-member-name">
                            <h4>Aana Abri <small>Gardener</small></h4>
                        </div>
                        v
                    </div>
                </div>
            </div><!--/.section-team-inner-->
        </div><!--/.container-->
    </div><!--/.section-team-->

    <div class="quote-section section-space">
        <div class="quote-bg">
            <img src="assets/img/qoute-bg.png" alt="">
        </div>
        <div class="container">
            <div class="quote-section-inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="quote-col image-col">
                            <img src="assets/img/quote-img.jpg" alt="quote image">
                            <div class="section-title text-center">
                                <i class="icon-lawn-mower"></i>
                                <h2>Get Instant Quote</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem, nihil?</p>
                            </div><!--/.quote-img-content-->
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="quote-form quote-col">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <label for="fullName"></label>
                                        <input type="text" id="fullName" placeholder="Full Name">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <input type="tel" placeholder="Phone no.">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <input type="email" placeholder="Email">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <select name="Service Required" id="" class="drp-dwn">
                                            <option value="">Service Required</option>
                                            <option value="">1</option>
                                            <option value="">1</option>
                                            <option value="">1</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quote-input">
                                        <input type="text" placeholder="Lawn Area (Sq ft)">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quote-input">
                                        <input type="text" placeholder="$0.00">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-message">
                                        <input type="text" placeholder="How can we Help?">
                                    </div>
                                </div>

                            </div>
                            <div class="button-group">
                                <button type="submit" class="btn-green-fill">get estimate</button>
                                <span>or Contact <a href="#">(01) 321 5105963</a></span>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div><!--/.container-->
    </div><!--/.quote-section-->
    <div class="news-blog section-space" style="background-image: url('assets/img/services-section-bg.jpg')">
        <div class="container">
            <div class="news-blog-inner">
                <div class="section-title text-center">
                    <i class="icon-lawn-mower"></i>
                    <h2>Latest<span>News Blog</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non, quas?</p>
                </div>
                <div class="blog-content">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="blog-figure">
                                <img src="assets/img/blog-img-1.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="blog-description">
                                <h4><small>garden, mowes, lawn</small>Lorem ipsum dolor sit amet</h4>
                                <p>Lorem ipsum dolor sit amet, ipsum dolor sit amet Lorem ipsum dolor sit amet, ipsum.</p>
                                <a href="#">read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="blog-figure">
                                <img src="assets/img/blog-img-2.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="blog-description">
                                <h4><small>garden, mowes, lawn</small>Lorem ipsum dolor sit amet</h4>
                                <p>Lorem ipsum dolor sit amet, ipsum dolor sit amet Lorem ipsum dolor sit amet, ipsum.</p>
                                <a href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="button-group text-center">
                        <button class="btn-no-fill">visit blog</button>
                    </div>
                </div><!--/.blog-content-->
            </div><!--/.news-blog-inner-->
        </div><!--/.container-->
    </div><!--/.news-blog-->
    <div class="clients-section section-space">
        <div class="container">
            <div class="clients-section-inner">
                <div class="owl-carousel owl-theme client-carousel">
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/sugarsync-logo.svg" alt="">
                        </div>

                    </div>
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/steam-logo.svg" alt="">
                        </div>

                    </div>
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/brand-logo.svg" alt="">
                        </div>

                    </div>
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/max-logo.svg" alt="">
                        </div>

                    </div>
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/box-logo.svg" alt="">
                        </div>

                    </div>
                    <div class="item">
                        <div class="client-logo">
                            <img src="assets/img/syncplicity-logo.svg" alt="">
                        </div>

                    </div>

                </div>
            </div><!--/.clients-section-inner-->
        </div><!--container-->
    </div><!--/.clients-section-->
    <div class="hm-contact-section section-space" style="background-image: url('assets/img/hero-image.jpg')">
        <div class="container">
            <div class="contact-section-inner">
                <div class="contact-descriptions text-center">
                    <h4>Call us today & get us make your garden beautifull</h4>
                    <h2><small>toll free</small> (01) 321 5105 953</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, voluptatibus?</p>
                </div>
            </div><!--/.contact-section-inner-->
        </div><!--/.container-->
    </div><!--/.contact-section-->
</div><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>
