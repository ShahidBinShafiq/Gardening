<?php include 'incl/header.php'; ?>

<div class="page__wrap">
    <div class="services-hero-img section-space" style="background-image: url('assets/img/hero-image-2.jpg')">
        <div class="service-content">
            <h1>services</h1>
            <a href="#">Home</a><span>></span><a href="#">Services</a>
        </div><!--/.services-content-->
    </div><!--/.services-hero-img-->
    <div class="service-description section-space-top">
        <div class="container">
            <div class="service-description-inner">
                <div class="row">
                    <div class="col-md-3">
                        <aside>
                            <ul>

                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>
                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>
                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>
                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>
                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>
                                <li style="background-image: url('assets/img/services-section-bg.jpg')"><a href="#"><i class="icon-heart"></i>landscape
                                        caring</a></li>

                            </ul>
                            <div class="dwnload-content">
                                <h4>Downloads</h4>
                                <div class="download-formate">
                                    <div class="formate-1 formate">
                                        <a href="#"> <i class="icon-angle-right"></i>
                                            <strong>Brouchure.PDF</strong></a>
                                    </div>
                                    <div class="formate-2 formate">
                                        <a href="#"><i class="icon-angle-right"></i>
                                            <strong>Brouchure.DOC</strong></a>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-content">
                                <h4>Testimonials</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium asperiores atque culpa cumque dolores
                                </p>
                                <strong>Kenn Thomson <small>Garden Owner</small></strong>
                            </div>
                            <div class="aside-image" style="background-image: url('assets/img/gardener-image-5.jpg')">
                                <div class="aside-image-content">
                                    <p>Get in Touch</p>
                                    <p><strong>Call (01) 321 5105963</strong></p>
                                    <p><strong>info@lanwexpress.com</strong></p>
                                </div>
                            </div>
                        </aside>
                    </div>
                    <div class="col-md-9">
                        <div class="description-details">
                            <div class="description-image">
                                <img src="assets/img/gardening-image-4.jpg" alt="">
                            </div>
                            <div class="section-title">
                                <h2>Watering <span>Gardens</span></h2>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium adipisci cumque delectus, doloribus, eaque,
                                eveniet ex facere fugit laboriosam magni minus modi molestiae mollitia nam necessitatibus nemo neque obcaecati
                                officiis omnis pariatur perferendis provident quibusdam reprehenderit similique sit soluta sunt suscipit tempora
                                temporibus ullam velit veritatis vero vitae! Doloremque, facilis.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci assumenda at, doloribus eveniet ex excepturi
                                facere minima mollitia nisi similique!</p>
                            <div class="service-stats-section">
                                <div class="stat-col">
                                    <i class="icon-clock"></i>
                                    <p><strong>Certified Workers</strong></p>
                                </div>
                                <div class="stat-col">
                                    <i class="icon-clock"></i>
                                    <p><strong>Certified Workers</strong></p>
                                </div>
                                <div class="stat-col">
                                    <i class="icon-clock"></i>
                                    <p><strong>Certified Workers</strong></p>
                                </div>
                                <div class="stat-col">
                                    <i class="icon-clock"></i>
                                    <p><strong>Certified Workers</strong></p>
                                </div>
                            </div>
                            <div class="service-stats-description">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid architecto dolor error laborum odio optio
                                    quasi vitae voluptas voluptatibus voluptatum. Alias consequatur minima perferendis rerum.</p>
                            </div>

                            <div class="services-inner-section-title">
                               <p><strong>Watering <span>Projects</span></strong></p>
                                <div class="pictorials">
                                    <div class="pictorial-col">
                                        <img src="assets/img/service-pictorial.jpg" alt="">
                                        <p><strong>Lorem ipsum dolor sit amet, consectetur.</strong></p>
                                        <ul>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                        </ul>
                                        <a href="#">View Details</a>
                                    </div>
                                    <div class="pictorial-col">
                                        <img src="assets/img/service-pictorial.jpg" alt="">
                                        <p><strong>Lorem ipsum dolor sit amet, consectetur.</strong></p>
                                        <ul>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                        </ul>
                                        <a href="#">View Details</a>
                                    </div>
                                    <div class="pictorial-col">
                                        <img src="assets/img/service-pictorial.jpg" alt="">
                                        <p><strong>Lorem ipsum dolor sit amet, consectetur.</strong></p>
                                        <ul>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                            <li><i class="icon-angle-right"></i>Lorem ipsum dolor.</li>
                                        </ul>
                                        <a href="#">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.services-description-inner-->
        </div><!--/.container-->
    </div><!--/.services-description-->
    <div class="quote-section section-space">
        <div class="quote-bg">
            <img src="assets/img/qoute-bg.png" alt="">
        </div>
        <div class="container">
            <div class="quote-section-inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="quote-col image-col">
                            <img src="assets/img/quote-img.jpg" alt="quote image">
                            <div class="section-title text-center">
                                <i class="icon-lawn-mower"></i>
                                <h2>Get Instant Quote</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem, nihil?</p>
                            </div><!--/.quote-img-content-->
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="quote-form quote-col">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <label for="fullName"></label>
                                        <input type="text" id="fullName" placeholder="Full Name">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <input type="tel" placeholder="Phone no.">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <input type="email" placeholder="Email">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-input">
                                        <select name="Service Required" id="" class="drp-dwn">
                                            <option value="">Service Required</option>
                                            <option value="">1</option>
                                            <option value="">1</option>
                                            <option value="">1</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quote-input">
                                        <input type="text" placeholder="Lawn Area (Sq ft)">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="quote-input">
                                        <input type="text" placeholder="$0.00">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="quote-message">
                                        <input type="text" placeholder="How can we Help?">
                                    </div>
                                </div>

                            </div>
                            <div class="button-group">
                                <button type="submit" class="btn-green-fill">get estimate</button>
                                <span>or Contact <a href="#">(01) 321 5105963</a></span>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div><!--/.container-->
    </div><!--/.quote-section-->
    <div class="hm-contact-section section-space" style="background-image: url('assets/img/hero-image.jpg')">
        <div class="container">
            <div class="contact-section-inner">
                <div class="contact-descriptions text-center">
                    <h4>Call us today & get us make your garden beautifull</h4>
                    <h2><small>toll free</small> (01) 321 5105 953</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, voluptatibus?</p>
                </div>
            </div><!--/.contact-section-inner-->
        </div><!--/.container-->
    </div><!--/.contact-section-->
</div>
<?php include 'incl/footer.php'; ?>
