<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Site Title</title>

    <link href="assets/img/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/img/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/img/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/img/favicon/manifest.json" rel="manifest">
    <link href="assets/img/favicon/favicon.ico" rel="shortcut icon">

    <style>
        .site__wrapper {
            opacity: 0;
            -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
            filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        }
    </style>


    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/simple-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body class="preload">

<div class="preload__wrap"></div>

<div class="site__wrapper">

    <header class="header__wrap">
        <div class="main-top-strip">
            <div class="container">
                <div class="top-strip-inner">
                    <div class="contact-section">
                        <ul>
                            <li><a href="#"><i class="icon-phone-alt"></i>+92 368 1234567</a></li>
                            <li class="top-strip-item"><a href="#"><i class="icon-envelope"></i>info@express.com</a></li>
                        </ul>
                    </div>
                    <div class="social-icons">
                        <ul>

                            <a href="#" class="ref-request">Quote Request</a>

                            <li class="social-media-icons">
                            <li><a href="#"><i class="icon-twitter"></i></a></li>
                            <li><a href="#"><i class="icon-facebook-f"></i></a></li>
                            <li><a href="#"><i class="icon-linkedin-in"></i></a></li>
                            <li><a href="#"><i class="icon-google-plus-g"></i></a></li>
                            <li><a href="#"><i class="icon-pinterest-p"></i></a></li>
                            </li>


                        </ul>
                    </div>
                </div><!--/.top-strip-inner-->
            </div><!--/.container-->
        </div><!--/.main-top-strip-->
        <div class="main-menu">
            <div class="container">
                <div class="menu-inner">
                    <nav class="navbar navbar-expand-lg navbar-light my-menu">
                        <a class="navbar-brand brand-name" href="#"><h4>Lawn Express <small>Creative Landscape Design</small></h4>
                            <i class="icon-exp-main"></i>
                        </a>
                        <button class="navbar-toggler menu-bars" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span><i class="icon-bars"></i></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="services.php">Services</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Our Works</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Store</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Blog</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <div class="menu-icons">
                            <a href="#"><i class="icon-shopping-basket"></i></a>
                            <a href="#"><i class="icon-search"></i></a>
                        </div>
                    </nav>
                </div><!--/.menu-inner-->
            </div><!--/.container-->
        </div><!--/.main-menu-->

    </header><!--/.header__wrap-->

