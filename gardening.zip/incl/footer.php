<footer class="footer__wrap">
    <div class="my-footer-wrap section-space" style="background-image: url('assets/img/hero-image-3.jpg')">
            <div class="container">
                <div class="footer-inner">
                    <div class="footer-content">
                        <div class="footer-col">
                            <a class="navbar-brand brand-name" href="#"><h4>Lawn Express <small>Creative Landscape Design</small></h4>
                                <i class="icon-exp-main"></i>
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci earum est eum id incidunt maiores, minima quas
                                quod sint tenetur!</p>

                            <ul>
                                <li><a href="#"><i class="icon-heart"></i>Brooks St 71, Washington DC, USA</a></li>
                                <li><a href="#"><i class="icon-phone-alt"></i>toll free (01) 321 5105 953</a></li>
                                <li><a href="#"><i class="icon-envelope"></i>info@lawnexpress.com</a></li>
                            </ul>
                        </div>
                        <div class="footer-col">
                           <h4>navigation</h4>
                            <ul>
                                <li><a href="#"><i class="icon-heart"></i>Home</a></li>
                                <li><a href="#"><i class="icon-heart"></i>About Us</a></li>
                                <li><a href="#"><i class="icon-heart"></i>Our Services</a></li>
                                <li><a href="#"><i class="icon-heart"></i>The Projects</a></li>
                                <li><a href="#"><i class="icon-heart"></i>Shop Online</a></li>
                                <li><a href="#"><i class="icon-heart"></i>Our News</a></li>
                                <li><a href="#"><i class="icon-heart"></i>Get in Touch</a></li>
                            </ul>
                        </div>
                        <div class="footer-col">
                           <h4>working hours</h4>
                            <p><strong>We are open 6 Days a week</strong></p>
                            <ul>
                                <li>Monday to  Friday: 9am to 5pm</li>
                                <li>Saturday: 10am to 4pm</li>
                                <li>Sunday: By Appointment Only</li>
                            </ul>
                            <p><span>Note:</span>We are also close on Bank and Calender Holidays</p>
                        </div>
                        <div class="footer-col">
                            <h4>newsletter</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing.</p>

                            <div class="button-group">
                                <form action="">
                                    <input type="email" placeholder="Email">
                                    <button type="button" class="btn-green-fill">subscribe</button>
                                </form>
                            </div>
                        </div>
                    </div><!--/footer-content-->
                </div><!--/.footer-inner-->
            </div><!--/container-->



    </div>
    <div class="footer-strip">
        <div class="container">
            <div class="footer-strip-inner">
                <div class="copy-rights">
                    <p>Copy rights 2020 <span>Lawnexpress</span> All rights reserved.</p>
                </div>
                <div class="social-icons">
                    <ul>

                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="#"><i class="icon-facebook-f"></i></a></li>
                        <li><a href="#"><i class="icon-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="icon-google-plus-g"></i></a></li>
                        <li><a href="#"><i class="icon-pinterest-p"></i></a></li>

                    </ul>
                </div>
            </div>

        </div>
    </div>
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->
<script src="assets/js/jquery-3.4.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.js"></script>
<script src="assets/js/owl.carousel.js"></script>
<script src="assets/js/simple-lightbox.min.js"></script>
<script src="assets/js/theme.js"></script>
<script>
    $(window).scroll(function () {

        // Write code here
        var scroll = $(window).scrollTop();
        if (scroll >= 40) {
            $(".main-menu").addClass("hdr-scroll");
        } else {
            $(".main-menu").removeClass("hdr-scroll");
        }
    });

    $('.team-carousel').owlCarousel({
        loop: true,
        margin: 30,
        nav: true,
        items: 4,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            }
        }
    })

    $(document).ready(function () {
        var lightbox = new SimpleLightbox('.gallery a', {
            maxZoom:25,
        });
    })

    $('.client-carousel').owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        items: 5,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 4
            },
            1000: {
                items: 5
            }
        }
    })

</script>

</body>
</html>

